# 09. 보안·성능·문서

프로젝트에 필요한 항목만 선택합니다.

| 목적 | Codex | Claude Code | 결과 |
|---|---|---|---|
| 보안 감사 | `gstack-cso` | `/cso` | 위험, 근거, 우선순위 |
| 성능 기준 | `gstack-benchmark` | `/benchmark` | 전후 측정과 회귀 여부 |
| 출시 문서 | `gstack-document-release` | `/document-release` | 코드와 일치하는 문서 |

Focus List에서는 사용자 입력이 HTML로 안전하게 표시되는지, 긴 목록에서도 반응성이 유지되는지, README의 실행·기능 설명이 실제 앱과 일치하는지 확인합니다.

결과를 `RELEASE-READINESS.md`에 기록하고 중대한 미해결 위험이 있으면 출시 단계로 넘어가지 않습니다.
