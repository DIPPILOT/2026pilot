const form = document.querySelector('#todo-form');
const input = document.querySelector('#todo-input');
const list = document.querySelector('#todo-list');
const count = document.querySelector('#count');
const emptyState = document.querySelector('#empty-state');

let todos = JSON.parse(localStorage.getItem('focus-list') || '[]');

function save() {
  localStorage.setItem('focus-list', JSON.stringify(todos));
}

function render() {
  list.innerHTML = '';

  todos.forEach((todo, index) => {
    const item = document.createElement('li');
    item.className = todo.done ? 'done' : '';
    item.innerHTML = `
      <input class="toggle" type="checkbox" ${todo.done ? 'checked' : ''}>
      <span class="todo-title">${todo.title}</span>
      <button class="delete" type="button">삭제</button>
    `;

    item.querySelector('.toggle').addEventListener('change', () => {
      todos[index].done = !todos[index].done;
      save();
      render();
    });

    item.querySelector('.delete').addEventListener('click', () => {
      todos.splice(index, 1);
      save();
      render();
    });

    list.appendChild(item);
  });

  count.textContent = `${todos.length}개`;
  emptyState.hidden = todos.length > 0;
}

form.addEventListener('submit', (event) => {
  event.preventDefault();
  todos.push({ title: input.value, done: false });
  save();
  input.value = '';
  render();
});

render();
