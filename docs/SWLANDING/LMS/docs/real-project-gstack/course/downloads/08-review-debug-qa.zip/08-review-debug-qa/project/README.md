# Focus List 실습 프로젝트

외부 패키지 없이 실행되는 작은 할 일 관리 웹 앱입니다.

## 실행

`index.html`을 브라우저에서 열거나 아래 명령으로 정적 서버를 실행합니다.

```bash
python3 -m http.server 8000
```

브라우저에서 `http://localhost:8000`을 엽니다.

## 실습 규칙

- 이 프로젝트에는 의도적으로 여러 문제가 남아 있습니다.
- 문제 목록은 먼저 공개하지 않습니다.
- gstack의 review, investigate, qa-only 스킬로 근거를 수집합니다.
- AI가 수정한 내용은 반드시 `git diff`로 검토합니다.
- 개인식별정보나 실제 비밀번호를 입력하지 않습니다.
