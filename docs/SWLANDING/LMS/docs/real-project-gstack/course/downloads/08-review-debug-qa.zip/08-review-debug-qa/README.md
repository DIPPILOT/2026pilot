# 08. 리뷰·디버깅·QA

## 코드 리뷰

Codex: `gstack-review` 스킬을 사용해 현재 diff를 검토하되 수정하지 말고 심각도, 파일 근거, 재현 방법만 보고하도록 요청합니다.

Claude Code: `/review` 뒤에 같은 제한을 입력합니다.

## 근본 원인 조사

Codex: `gstack-investigate` 스킬로 재현, 증거, 가설을 먼저 만들고 승인 전에는 수정하지 않도록 요청합니다.

Claude Code: `/investigate`

## QA

- 보고 전용: Codex `gstack-qa-only`, Claude `/qa-only`
- 승인한 결함 수정과 재검증: Codex `gstack-qa`, Claude `/qa`

정상 입력, 빈/공백, 중복, 긴 입력, 연속 클릭, 새로고침, 모바일 폭을 확인하고 `QA-REPORT.md`를 작성합니다.
