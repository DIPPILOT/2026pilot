# 4단계 - 코드 리뷰와 QA

이 프로젝트에는 의도적인 문제가 포함되어 있습니다. 먼저 답을 보지 말고 gstack으로 근거를 수집하세요.

## 작업 전

```bash
git status
git diff
```

## Codex 코드 리뷰

```text
gstack-review 스킬을 사용해 현재 프로젝트를 검토해 줘.
잠재 버그, 예외 처리 누락, 테스트 누락, 불필요한 복잡성을 확인해 줘.
이번 실습에서는 수정하지 말고 심각도와 근거만 보고해 줘.
```

## Claude Code 코드 리뷰

```text
/review
```

이어서 `수정하지 말고 심각도와 근거만 보고해 줘`라고 제한합니다.

## QA 보고서

Codex는 `gstack-qa-only`, Claude Code는 `/qa-only`를 사용합니다.

정상 입력, 빈 입력, 공백 입력, 긴 입력, 빠른 연속 클릭,
새로고침, 작은 화면을 확인하고 재현 절차와 심각도를 기록하세요.

## 작업 후

```bash
git status
git diff
```
