# 10. 출시와 회고

## 출시

- PR 준비: Codex `gstack-ship`, Claude `/ship`
- 실제 배포 환경이 준비된 경우: Codex `gstack-land-and-deploy`, Claude `/land-and-deploy`
- 배포 후 감시가 필요한 경우: Codex `gstack-canary`, Claude `/canary`

`ship`은 커밋과 원격 변경을 만들 수 있습니다. 실행 전 현재 브랜치, diff, 테스트 결과를 사람이 확인합니다. 수업에서는 원격 저장소가 없으므로 `SHIP-CHECKLIST.md`를 채우는 것으로 대체할 수 있습니다.

## 회고

- Codex: `gstack-retro`, `gstack-learn`
- Claude Code: `/retro`, `/learn`

AI가 발견한 내용뿐 아니라 잘못 가정한 내용, 사람이 내린 결정, 다음 프로젝트에서 재사용할 규칙을 기록합니다.
