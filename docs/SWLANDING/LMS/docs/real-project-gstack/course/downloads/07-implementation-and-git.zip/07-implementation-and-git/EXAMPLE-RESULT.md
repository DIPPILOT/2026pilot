# 구현 결과 예시

```text
$ git diff --stat
 app.js | 12 ++++++++++--
 1 file changed, 10 insertions(+), 2 deletions(-)

$ git status --short
 M app.js
```

브라우저 확인:
- 공백 입력: 항목 0개 유지, 안내 표시
- 정상 입력: 항목 1개 추가
- 기존 완료 버튼: 정상 동작

계획에 없던 파일이 바뀌면 커밋하지 않고 원인을 확인합니다.
