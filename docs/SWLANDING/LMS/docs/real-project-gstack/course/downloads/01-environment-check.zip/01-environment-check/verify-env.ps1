$commands = @("git", "node", "npm", "bun", "codex", "claude")

Write-Host "gstack 실습 환경 점검" -ForegroundColor Green
Write-Host "----------------------"

foreach ($command in $commands) {
    if (Get-Command $command -ErrorAction SilentlyContinue) {
        try {
            $version = & $command --version 2>$null | Select-Object -First 1
            Write-Host "[OK] $command $version" -ForegroundColor Green
        }
        catch {
            Write-Host "[FOUND] $command - 버전 확인 필요" -ForegroundColor Yellow
        }
    }
    else {
        Write-Host "[MISSING] $command" -ForegroundColor Red
    }
}

Write-Host ""
Write-Host "Codex 또는 Claude Code 중 하나만 선택했다면 다른 하나가 없어도 됩니다."
