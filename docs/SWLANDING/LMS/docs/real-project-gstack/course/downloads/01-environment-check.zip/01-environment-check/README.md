# 1단계 - 환경 점검과 Windows 설치

## 목표

Codex 또는 Claude Code와 gstack을 설치하기 전 필수 도구를 확인합니다.

## 공통 확인

```bash
git --version
bun --version
```

## Codex 확인

```bash
codex --version
```

## Claude Code 확인

```bash
claude --version
claude doctor
```

## gstack 설치 상태

gstack 체크아웃 폴더에서 실행합니다.

```bash
./setup --status
```

`CHECKLIST.md`에 결과를 기록하세요.

## Windows 학습자

- 처음 설치한다면 `WINDOWS-NATIVE.md`를 먼저 읽으세요.
- WSL2를 선택한 경우에만 `WSL2-OPTION.md`를 사용하세요.
- PowerShell 점검은 다음처럼 실행합니다.

```powershell
powershell -ExecutionPolicy Bypass -File .\verify-env.ps1
```
