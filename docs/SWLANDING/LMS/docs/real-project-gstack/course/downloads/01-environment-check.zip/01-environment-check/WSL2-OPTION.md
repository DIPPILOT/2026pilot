# WSL2 설치 - 선택 과정

WSL은 Windows 안에서 Ubuntu Linux 개발 환경을 실행하는 기능입니다. 초급 강의에서는 필수가 아닙니다. Linux 환경으로 통일하고 싶을 때 선택합니다.

## 1. WSL2 설치

PowerShell을 관리자 권한으로 열고 실행합니다.

```powershell
wsl --install
```

컴퓨터를 재부팅한 뒤 시작 메뉴에서 `Ubuntu`를 실행합니다. 처음 실행할 때 Linux 사용자 이름과 비밀번호를 만듭니다. 비밀번호 입력 중에는 화면에 문자가 보이지 않는 것이 정상입니다.

PowerShell에서 WSL2 상태를 확인합니다.

```powershell
wsl --list --verbose
```

Ubuntu의 VERSION이 2여야 합니다.

## 2. 이후 명령은 Ubuntu에서 실행

```bash
sudo apt update
sudo apt install -y git curl unzip
curl -fsSL https://bun.com/install | bash
source ~/.bashrc
```

Codex와 Claude Code를 Ubuntu 안에 설치합니다.

```bash
curl -fsSL https://chatgpt.com/codex/install.sh | sh
curl -fsSL https://claude.ai/install.sh | bash
```

gstack도 Ubuntu 안에 설치합니다.

```bash
git clone --single-branch --depth 1 https://github.com/garrytan/gstack.git ~/gstack
cd ~/gstack
./setup --host codex
./setup --host claude
./setup --status
```

## 환경을 섞지 않기

Codex만 Windows에 설치하고 gstack은 WSL에 설치하면 서로 다른 홈 폴더를 사용합니다. 다음 중 하나로 통일하세요.

- 모두 Windows PowerShell에 설치
- 모두 WSL2 Ubuntu에 설치
