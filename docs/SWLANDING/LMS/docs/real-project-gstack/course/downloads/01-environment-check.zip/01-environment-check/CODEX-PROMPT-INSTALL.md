# Codex에게 프롬프트로 gstack 설치 요청하기

> Codex CLI 자체 설치와 로그인은 먼저 완료해야 합니다. 이 과정은 Codex를 실행한 뒤 gstack 설치를 맡기는 방법입니다.

## 1. 환경 점검 프롬프트

```text
gstack 설치를 준비하고 있어.
먼저 현재 운영체제와 셸을 확인하고,
Git, Bun, Codex 버전과 기존 gstack 설치 여부를 점검해 줘.

아직 설치하거나 파일을 수정하지 말고,
확인한 사실, 부족한 항목, 사용할 설치 경로와
실행할 명령 계획만 보여 줘.
```

확인할 것:
- 운영체제와 셸이 실제 환경과 같은가?
- 기존 gstack 폴더가 있는가?
- 설치 경로가 내 홈 폴더 아래인가?
- 부족한 도구가 무엇인가?

## 2. 설치 실행 프롬프트

```text
방금 점검한 결과를 기준으로 gstack을 Codex host에 설치해 줘.

조건:
1. https://github.com/garrytan/gstack 공식 저장소만 사용해.
2. Windows 네이티브면 $HOME\gstack과 setup.ps1을 사용하고,
   macOS·Linux·WSL이면 ~/gstack과 ./setup을 사용해.
3. 기존 gstack 폴더가 있으면 덮어쓰거나 삭제하지 말고 멈춰서 알려 줘.
4. 파괴적인 명령은 실행하지 마.
5. 네트워크 접근이나 홈 폴더 쓰기가 필요하면 먼저 승인을 요청해.
6. 설치 후 --host codex 등록과 --status 확인까지 실행해.
7. 마지막에 실행한 명령, 설치 경로, 상태 결과를 요약해.
```

승인 창에서는 명령, 공식 저장소 주소, 설치 경로, 삭제 명령 유무를 확인합니다. 이해하지 못한 명령은 승인하지 말고 설명을 요청합니다.

## 3. 첫 사용 프롬프트

Codex를 완전히 종료하고 실습 폴더에서 새 세션을 시작합니다.

```text
먼저 gstack-office-hours 스킬을 사용할 수 있는지 확인해 줘.
사용 가능하면 이 프로젝트를 읽고 다음을 정리해 줘.

1. 대상 사용자
2. 사용자가 겪는 문제
3. 가장 작은 핵심 기능
4. 검증되지 않은 가정

아직 파일을 수정하지 마.
```

## 예상 결과 예시

```text
환경: Windows 11 / PowerShell 7
확인됨: Git 2.x, Bun 1.x, Codex 로그인
설치 경로: C:\Users\student\gstack
등록 host: codex
상태: installed / skills linked
다음 단계: Codex를 재시작하고 gstack-office-hours 실행
```

비밀번호, 인증 코드, API 키는 프롬프트나 제출물에 넣지 않습니다.
