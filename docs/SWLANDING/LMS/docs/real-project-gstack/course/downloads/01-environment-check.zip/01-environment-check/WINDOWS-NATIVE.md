# Windows 네이티브 설치 - 초급자용

이 과정에서는 WSL을 설치하지 않고 Windows PowerShell에서 Codex, Claude Code, gstack을 사용합니다.

## 1. PowerShell 열기

1. 키보드의 Windows 키를 누릅니다.
2. `PowerShell`을 검색합니다.
3. `Windows PowerShell` 또는 `PowerShell`을 실행합니다.

명령은 `PS C:\Users\사용자이름>` 뒤에 입력합니다. `PS ...>` 부분은 입력하지 않습니다.

## 2. Git과 Node.js 설치

```powershell
winget install --id Git.Git -e
winget install OpenJS.NodeJS.LTS
```

PowerShell을 닫고 새로 연 뒤 확인합니다.

```powershell
git --version
node --version
npm --version
```

## 3. Bun 설치

```powershell
powershell -c "irm bun.sh/install.ps1|iex"
```

PowerShell을 다시 열고 확인합니다.

```powershell
bun --version
```

## 4. Codex 설치

```powershell
powershell -ExecutionPolicy ByPass -c "irm https://chatgpt.com/codex/install.ps1 | iex"
```

새 PowerShell에서 확인하고 로그인합니다.

```powershell
codex --version
codex
```

## 5. Claude Code 설치

```powershell
winget install Anthropic.ClaudeCode
```

새 PowerShell에서 확인하고 로그인합니다.

```powershell
claude --version
claude doctor
claude
```

## 6. gstack 설치

```powershell
git clone --single-branch --depth 1 https://github.com/garrytan/gstack.git "$HOME\gstack"
cd "$HOME\gstack"
```

Codex와 Claude Code에 각각 등록합니다.

```powershell
.\setup.ps1 --host codex
.\setup.ps1 --host claude
.\setup.ps1 --status
```

스크립트 실행이 차단되면 다음처럼 실행합니다.

```powershell
powershell -ExecutionPolicy Bypass -File .\setup.ps1 --host codex
powershell -ExecutionPolicy Bypass -File .\setup.ps1 --host claude
```

## 7. ZIP 실습 파일 시작

1. ZIP 파일을 다운로드합니다.
2. 파일을 마우스 오른쪽 버튼으로 누릅니다.
3. `압축 풀기` 또는 `모두 추출`을 선택합니다.
4. 압축을 푼 `project` 폴더를 엽니다.
5. 탐색기 주소 표시줄에 `powershell`을 입력하고 Enter를 누릅니다.

열린 PowerShell에서 실행합니다.

```powershell
git init
git add .
git commit -m "실습 시작 상태"
git status
```

커밋 과정에서 이름과 이메일을 요구하면 이 실습 폴더에만 설정합니다.

```powershell
git config user.name "student"
git config user.email "student@example.local"
git commit -m "실습 시작 상태"
```

## 8. 첫 실행

Codex:

```powershell
codex
```

Claude Code:

```powershell
claude
```

AI 작업 전후에 다음을 확인합니다.

```powershell
git status
git diff
```
