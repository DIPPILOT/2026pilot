# 환경 점검표

- [ ] Git 버전이 표시된다.
- [ ] Bun 1.4.2 이상이 설치되어 있다.
- [ ] Codex 또는 Claude Code가 실행된다.
- [ ] 계정 로그인이 완료됐다.
- [ ] gstack 설치 상태에서 선택한 host가 표시된다.
- [ ] 실습 폴더에서 `git status`가 실행된다.

## 내 환경

- 운영체제:
- 선택한 도구: Codex / Claude Code
- Git 버전:
- Bun 버전:
- gstack 버전:
- 해결하지 못한 문제:
