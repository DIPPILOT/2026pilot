#!/usr/bin/env bash
set -u

check() {
  if command -v "$1" >/dev/null 2>&1; then
    printf '[OK] %-8s %s\n' "$1" "$("$1" --version 2>/dev/null | head -1)"
  else
    printf '[MISSING] %s\n' "$1"
  fi
}

check git
check bun
check codex
check claude

printf '\n하나의 AI 도구만 선택했다면 codex 또는 claude 중 하나가 없어도 됩니다.\n'
