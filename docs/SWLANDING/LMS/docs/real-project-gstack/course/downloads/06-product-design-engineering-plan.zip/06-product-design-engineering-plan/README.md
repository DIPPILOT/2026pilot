# 06. 제품·디자인·기술 계획

명세를 세 관점으로 검토합니다. 이 단계에서도 구현하지 않습니다.

| 관점 | Codex 스킬 | Claude Code |
|---|---|---|
| 제품 범위 | `gstack-plan-ceo-review` | `/plan-ceo-review` |
| 사용자 경험 | `gstack-plan-design-review` | `/plan-design-review` |
| 기술 구조 | `gstack-plan-eng-review` | `/plan-eng-review` |
| 연속 검토 | `gstack-autoplan` | `/autoplan` |

기술 검토 요청 예시:

```text
gstack-plan-eng-review 스킬을 사용해 현재 명세를 검토해 줘. 변경 파일, 데이터 흐름, 실패 경로, 테스트 항목, 구현 순서를 포함하고 아직 구현하지 마.
```

각 제안을 실제 파일과 비교하고 `PLAN.md`에 최종 결정을 기록합니다.
