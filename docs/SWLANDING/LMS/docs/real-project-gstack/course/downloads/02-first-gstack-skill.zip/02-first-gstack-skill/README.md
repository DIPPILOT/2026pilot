# 2단계 - 첫 gstack 스킬 실행

`project/` 폴더에서 Codex 또는 Claude Code를 실행하세요.

## Codex

```text
gstack-office-hours 스킬을 사용해 이 프로젝트를 검토해 줘.

대상 사용자, 해결하려는 문제, 핵심 가치, 가장 작은 핵심 기능,
검증되지 않은 가정을 정리해 줘. 아직 코드를 수정하지 마.
```

## Claude Code

```text
/office-hours
```

이어서 입력합니다.

```text
이 프로젝트의 대상 사용자, 해결하려는 문제, 핵심 가치와
가장 작은 핵심 기능을 검토해 줘. 아직 코드를 수정하지 마.
```

## 종료 확인

```bash
git status
git diff
```

예상하지 않은 파일 변경이 없어야 합니다.
